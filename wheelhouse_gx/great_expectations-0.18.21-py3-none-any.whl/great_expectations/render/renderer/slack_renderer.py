from __future__ import annotations

import logging
from datetime import datetime

logger = logging.getLogger(__name__)

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from great_expectations.core import RunIdentifier

from great_expectations.render.renderer.renderer import Renderer


class SlackRenderer(Renderer):
    def __init__(self) -> None:
        super().__init__()

    def render(  # noqa: C901, PLR0912, PLR0913, PLR0915
        self,
        name: str,
        checkpoint_name: str,
        validation_result=None,
        data_docs_pages=None,
        notify_with=None,
        show_failed_expectations: bool = False,
        validation_result_urls: list[str] | None = None,
    ):
        if validation_result_urls is None:
            validation_result_urls = []

        status = "Failed :no_entry:"
        if validation_result and validation_result.success:
            status = "Success :white_check_mark:"
        title_block = {
            "type": "header",
            "text": {
                "type": "plain_text",
                "text": f"{name} - {checkpoint_name} - {status}",
            },
        }

        query = {
            "blocks": [title_block],
        }

        if validation_result:
            expectation_suite_name = validation_result.meta.get(
                "expectation_suite_name", "__no_expectation_suite_name__"
            )

            if "batch_kwargs" in validation_result.meta:
                data_asset_name = validation_result.meta["batch_kwargs"].get(
                    "data_asset_name", "__no_data_asset_name__"
                )
            elif "active_batch_definition" in validation_result.meta:
                data_asset_name = (
                    validation_result.meta["active_batch_definition"].data_asset_name
                    if validation_result.meta["active_batch_definition"].data_asset_name
                    else "__no_data_asset_name__"
                )
            else:
                data_asset_name = "__no_data_asset_name__"

            validation_link = None
            summary_text = ""
            if validation_result_urls:
                if len(validation_result_urls) == 1:
                    validation_link = validation_result_urls[0]
                else:
                    title_hlink = "*Validation Results*"
                    batch_validation_status_hlinks = "".join(
                        f"*<{validation_result_url} | {status}>*"
                        for validation_result_url in validation_result_urls
                    )
                    summary_text += f"""{title_hlink}
                {batch_validation_status_hlinks}
                            """

            summary_text += f"*Asset*: {data_asset_name}  "
            # Slack does not allow links to local files due to security risks
            # DataDocs links will be added in a block after this summary text when applicable
            if validation_link and "file://" not in validation_link:
                summary_text += f"*Expectation Suite*: {expectation_suite_name}  <{validation_link}|View Results>"
            else:
                summary_text += f"*Expectation Suite*: {expectation_suite_name}"

            description = {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": summary_text,
                },
            }

            query["blocks"].append(description)

            if data_docs_pages:
                if notify_with is not None:
                    for docs_link_key in notify_with:
                        if docs_link_key in data_docs_pages.keys():
                            docs_link = data_docs_pages[docs_link_key]
                            report_element = self._get_report_element(docs_link)
                        else:
                            logger.critical(
                                f"*ERROR*: Slack is trying to provide a link to the following DataDocs: `"
                                f"{docs_link_key!s}`, but it is not configured under `data_docs_sites` in the "
                                f"`great_expectations.yml`\n"
                            )
                            report_element = {
                                "type": "section",
                                "text": {
                                    "type": "mrkdwn",
                                    "text": f"*ERROR*: Slack is trying to provide a link to the following DataDocs: "
                                    f"`{docs_link_key!s}`, but it is not configured under "
                                    f"`data_docs_sites` in the `great_expectations.yml`\n",
                                },
                            }
                        if report_element:
                            query["blocks"].append(report_element)
                else:
                    for docs_link_key in data_docs_pages.keys():
                        if docs_link_key == "class":
                            continue
                        docs_link = data_docs_pages[docs_link_key]
                        report_element = self._get_report_element(docs_link)
                        if report_element:
                            query["blocks"].append(report_element)

        divider_block = {"type": "divider"}
        query["blocks"].append(divider_block)
        if validation_result and validation_result.meta:
            query["blocks"].insert(
                1, self._build_run_time_block(run_id=validation_result.meta["run_id"])
            )
        return query

    def _build_run_time_block(self, run_id: RunIdentifier) -> dict:
        if run_id is not None:
            run_time = datetime.fromisoformat(str(run_id.run_time))
            formatted_run_time = run_time.strftime("%Y/%m/%d %I:%M %p")
            formatted_run_time += " UTC"
        return {
            "type": "section",
            "text": {"type": "plain_text", "text": f"Runtime: {formatted_run_time}"},
        }

    def _get_report_element(self, docs_link):
        report_element = None
        if docs_link:
            try:
                # Slack does not allow links to local files due to security risks
                if "file://" in docs_link:
                    report_element = {
                        "type": "section",
                        "text": {
                            "type": "mrkdwn",
                            "text": f"*DataDocs* can be found here: `{docs_link}` \n (Please copy and paste link into "
                            f"a browser to view)\n",
                        },
                    }
                else:
                    report_element = {
                        "type": "section",
                        "text": {
                            "type": "mrkdwn",
                            "text": f"*DataDocs* can be found here: <{docs_link}|{docs_link}>",
                        },
                    }
            except Exception as e:
                logger.warning(
                    f"""SlackRenderer had a problem with generating the docs link.
                    link used to generate the docs link is: {docs_link} and is of type: {type(docs_link)}.
                    Error: {e}"""
                )
                return
        else:
            logger.warning(
                "No docs link found. Skipping data docs link in Slack message."
            )
        return report_element

    def create_failed_expectations_text(self, validation_results: list[dict]) -> str:
        failed_expectations_str = "\n*Failed Expectations*:\n"
        for expectation in validation_results:
            if not expectation["success"]:
                expectation_name = expectation["expectation_config"]["expectation_type"]
                expectation_kwargs = expectation["expectation_config"]["kwargs"]
                failed_expectations_str += self.create_failed_expectation_text(
                    expectation_kwargs, expectation_name
                )
        return failed_expectations_str

    def create_failed_expectation_text(
        self, expectation_kwargs, expectation_name
    ) -> str:
        expectation_entity = self.get_failed_expectation_domain(
            expectation_name, expectation_kwargs
        )
        if expectation_entity:
            return f":x:{expectation_name} ({expectation_entity})\n"
        return f":x:{expectation_name}\n"

    @staticmethod
    def get_failed_expectation_domain(
        expectation_name, expectation_config_kwargs: dict
    ) -> str:
        if "expect_table_" in expectation_name:
            return "Table"

        column_name, column_a, column_b, column_list = (
            expectation_config_kwargs.get("column"),
            expectation_config_kwargs.get("column_A"),
            expectation_config_kwargs.get("column_B"),
            expectation_config_kwargs.get("column_list"),
        )
        if column_name:
            return column_name
        elif column_a and column_b:
            return f"{column_a}, {column_b}"
        elif column_list:
            return str(column_list)
